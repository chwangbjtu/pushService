#ifndef _NETSVC_INIT_H
#define _NETSVC_INIT_H

#ifdef WIN32
#include "win/netsvc_init.h"
#else
#include "linux/netsvc_init.h"
#endif

#endif


