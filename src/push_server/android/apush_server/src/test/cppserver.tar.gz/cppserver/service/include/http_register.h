#ifndef __HTTP_REGISTER_H
#define __HTTP_REGISTER_H


class http_register
{
public:
	http_register(){};
	~http_register(){};
	int start();
private:
	static bool init;
};
#endif //__HTTP_REGISTER_H



